﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Apixelados2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MonedaController : ControllerBase
    {
        private static List<Moneda> list = new List<Moneda>();

        [HttpPost]

        public IActionResult Post([FromBody]Moneda m)
        {
            if(m == null || string.IsNullOrEmpty(m.Nombre))
            {
                return BadRequest("Datos Incorrectos");
            }
            else
            {
                list.Add(m);
                return Ok("Moneda Registrada");
            }

        }

        [HttpGet] 

        public IActionResult Get()
        {
            return Ok(list);
        }

        [HttpGet("{nombre}")]

        public IActionResult Get(string nombre)
        {
            foreach(Moneda x in list)
            {
                if (x.Nombre.Equals(nombre))
                    return Ok(x);   
            }
            return NotFound("Moneda no Registrada");
        }


    }
}
