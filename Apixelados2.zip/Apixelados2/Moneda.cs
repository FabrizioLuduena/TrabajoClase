﻿namespace Apixelados2
{
    public class Moneda
    {
        public string Nombre { get; set; }

        public int Valor { get; set; }
    }
}
