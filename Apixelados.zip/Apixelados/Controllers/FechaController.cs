﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Tracing;

namespace Apixelados.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FechaController : ControllerBase
    {
        private string[] diaSemana;

        public FechaController() 
        {
            diaSemana = new string[] {"Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"};
        }


        [HttpGet] //ruta por defecto (raiz)
        public IActionResult Get()
        {
            var fec = DateTime.Now;
            var value = new Fecha()
            {
                Numero = fec.Day,
                //Dia = fec.DayOfWeek.ToString(),
                Dia = diaSemana[(int)fec.DayOfWeek],
                Mes = fec.Month,
                Anio= fec.Year,
            };

            return Ok(value);
        }
    }
}
