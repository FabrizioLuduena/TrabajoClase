﻿namespace Apixelados
{
    public class Fecha
    {
        public int Numero { get; set; }

        public string Dia { get; set; }

        public int Mes { get; set; } 

        public int Anio { get; set; }

    }
}
